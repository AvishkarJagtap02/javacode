

class Sample {
	public static void main(String args[]) {
		int n=3;
		for(int i=3;i>=0;i--) {
			for(int j=i;j<=n;j++) {
				System.out.print(j);
				
			}
			
			System.out.println();
		}

	}
}

