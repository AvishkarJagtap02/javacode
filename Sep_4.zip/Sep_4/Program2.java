
import java.util.*;
class Sample {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("Second Predecessor:"+(n-2));
		System.out.println("Second Sucessor:"+(n+2));
	}
}



