
class Sample {
	public static void main(String args[]) {
		for(int i=1;i<=4;i++) {
			int n=2;
			for(int j=1;j<=4;j++) {
				System.out.print(n+" ");
				n=n+2;
			}
			System.out.println();
		}
	}
}

