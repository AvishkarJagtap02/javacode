
class Sample {
        public static void main(String args[]) {
                for(int i=1;i<=20;i++) {
                        System.out.println("cube of "+i+" is: "+(i*i*i));
                }
        }
}
