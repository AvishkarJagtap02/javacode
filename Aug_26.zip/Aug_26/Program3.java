class Sample {
	public static void main(String args[]) {
		for(int i=1;i<=10;i++) {
			int n=2;
			n=n*i;
			System.out.print(n+" ");
		}
		System.out.println();
	}
}



