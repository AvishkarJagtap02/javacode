


import java.util.*;
class Sample {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String ID : ");
		String SID=sc.nextLine();
		System.out.println("Enter numerical  ID : ");
		String NID=sc.nextLine();
		System.out.println("Your email id is: ");
		System.out.println(SID+""+NID+"@gmail.com");
	}
}


