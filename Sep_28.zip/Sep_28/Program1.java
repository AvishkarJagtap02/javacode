

import java.util.*;
class Sample {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		String Name=sc.nextLine();
		int Roll_no=sc.nextInt();
		String Interest=sc.next();

		System.out.println("Hey,my name is "+Name+" and my roll number is "+Roll_no+". My Field of Interest are "+ Interest +".");
	}
}
