


import java.util.*;
class Sample {
        public static void main(String args[]) {
                Scanner sc=new Scanner(System.in);
                String String1=sc.nextLine();
                String String2=sc.next();
		System.out.println(String1+" "+String2);
	}
}


