




class Sample {
	public static void main(String[] args) {
		for(int i=1;i<=5;i++) {
			for(int j=i;j<=5;j++) {
				System.out.print("=\t");
			}
			System.out.println();
		}
			for(int k=1;k<=5;k++) {
				for(int p=1;p<=k;p++) {
					System.out.print("*\t");
				}
				System.out.println();
			}
	}
}

