

import java.util.*;
class Sample {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		long n=sc.nextLong();
		long Seconds=n*60*60;
		System.out.println(Seconds+" Seconds");
	}
}

