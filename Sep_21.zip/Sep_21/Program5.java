
import java.io.*;
class Sample {
	public static void main(String s[])throws IOException {
		int x,y,s1;
		x=Integer.parseInt(s[0]);
		y=Integer.parseInt(s[1]);

		s1=x+y;
	
		System.out.println("The sum of "+x+" & "+y+" is "+s1);
	}
}

