


import java.util.*;
class Sample {
	public static void main(String args[])  {
		Scanner sc=new Scanner(System.in);
		System.out.println("Mass = ");
		int m=sc.nextInt();
		System.out.println("Velocity = ");
		int v=sc.nextInt();
		System.out.println("The Kinetic Energy Of that object is :"+(0.5*m*v*v));
	}
}

