

import java.util.*;
class Sample {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Number :");
		System.out.println(" Real Part :");
		int r1=sc.nextInt();
		System.out.println("Imaginary Part :");
		int i1=sc.nextInt();
		System.out.println("Enter Second Number :");
		System.out.println(" Real Part :");
		int r2=sc.nextInt();
		System.out.println("Imaginary Part :");
		int i2=sc.nextInt();
		System.out.println("The Addition of "+r1+"+"+i1+"i & "+r2+"+"+i2+"i is "+(r1+r2)+"+"+(i1+i2)+"i");
	}
}






