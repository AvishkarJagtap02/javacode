

import java.util.*;
class Sample {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int q=a/b;
		int rem=a%b;
		System.out.println("Quotient:"+q);
		System.out.println("Reminder:"+rem);
	}
}


