


class Sample {
	public static void main(String args[]) {
		int I=10;
		int R=5;
		System.out.println("Output Voltage = "+(I*R));
	}
}

